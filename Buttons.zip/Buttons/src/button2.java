import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class button2 {
    static int counter;
    static JLabel label = new JLabel("The value of counter is: " + counter);

    public static void main(String[] args) {
        JFrame frame = new JFrame("Frame with a counter");
        frame.setBounds(500, 500, 300, 400);
        JButton button = new JButton("Increase");
        //adding actionListener to button:
        button.addActionListener(e -> {
            counter++;
            label.setText("After increasing the value of counter is: " +counter);
        });
        frame.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 50));
        frame.add(button);
        frame.add(label);
        JButton button1 = new JButton("Decrease");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                counter--;
                label.setText("After decreasing the value of counter is: "+counter);
            }
        });
        frame.add(button1);
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(3);
    }

}