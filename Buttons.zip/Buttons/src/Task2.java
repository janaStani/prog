class Vehicle {
    private String color;
    private int numWheels;

    public Vehicle(String color, int numWheels) {
        this.color = color;
        this.numWheels = numWheels;
    }

    public void setColor(String color) {
        this.color = color;
    }
    public String getColor() {
        return color;
    }

    public void setNumWheels(int numWheels) {
        this.numWheels = numWheels;
    }

    public int getNumWheels() {
        return numWheels;
    }

    public void print() {
        System.out.println("Color: " + color + ", Number of wheels: " + numWheels);
    }
}

class Truck extends Vehicle {
    private int loadCapacity;

    public Truck(String color, int numWheels, int loadCapacity) {
        super(color, numWheels);
        this.loadCapacity = loadCapacity;
    }

    public void setLoadCapacity(int loadCapacity) {
        this.loadCapacity = loadCapacity;
    }

    public int getLoadCapacity() {
        return loadCapacity;
    }

    @Override
    public void print() {
        super.print();
        System.out.println("Load capacity: " + loadCapacity);
    }
}

class Engine extends Vehicle {
    public Engine(String color, int numWheels) {
        super(color, numWheels);
    }
}

class Fleet {
    public static void main(String[] args) {
        Truck truck = new Truck("Red", 8, 10000);
        Engine engine = new Engine("Blue", 6);
        truck.print();
        engine.print();
    }
}
