import javax.swing.*;
import java.awt.*;

public class button1 {
        static int counter=1;
        static JLabel label = new JLabel("0" +counter);

        public static void main(String[] args) {
            JFrame frame = new JFrame("Frame with a counter");
            frame.setBounds(500, 500, 300, 200);
            JButton button =new JButton();
            //adding actionListener to button:
            button.addActionListener(e -> {
                counter++;
                label.setText(String.valueOf(counter));
            });
            frame.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
            frame.add(button);
            frame.add(label);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(3);

    }
}
