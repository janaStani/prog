import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter amount of elements");
        int a=sc.nextInt();
        System.out.println("Enter the elements ");
        int [] arr = new int[a];
        for (int i=0; i<arr.length; i++){
            arr[i]=sc.nextInt();
        }
        int sum=0;
        for (int i=0; i<arr.length; i++){
            if (arr[i]%2!=0)
                sum += arr[i]*arr[i];
        }
        System.out.println("The sum of all od squares is: "+sum);
        int product=1;
        for (int i=0; i<arr.length; i++){
            if (arr[i]%2==0)
                product *= arr[i];
        }
        System.out.println("The product of all even numbers is: "+product);
        System.out.println("The difference is: "+((sum)-(product)));
    }
}
