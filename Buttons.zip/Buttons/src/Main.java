import javax.swing.*;
import java.awt.*;


public class Main {
    static int num = 16;
    //static Button closeButton, numberButton;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Window with Buttons");
        frame.setSize(400, 200);
        frame.setLayout(new GridLayout(1,2));

        JButton button = new JButton("Close");
        button.setPreferredSize(new Dimension(200, 200));
        button.addActionListener(e -> System.exit(0));
        frame.add(button);

        JButton button2  = new JButton(Integer.toString(num));
        button2.setPreferredSize(new Dimension(200, 200));
        button2.addActionListener(e -> {
            if (num > 1) {
                num /= 2;
                button2.setText(Integer.toString(num));
            }
        });
        frame.add(button2);

        frame.setVisible(true);
    }
}
