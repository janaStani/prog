import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class Task1 {
    static int number=16;
    public static void main(String[] args) {
        JFrame frame = new JFrame("Task1");
        frame.setSize(400,200);
        frame.setLayout(new GridLayout(1,2));

        JButton button = new JButton("Close");
        button.setSize(200,200);
        button.addActionListener(e -> {
            System.exit(0);
        });
        frame.add(button);
        JButton button2 = new JButton(Integer.toString(number));
        button2.setSize(200,200);
        button2.addActionListener(e -> {
            if (number >= 2)
                number = number / 2;
            button2.setText(Integer.toString(number));
        });
        frame.add(button2);
        frame.setVisible(true);
    }
}