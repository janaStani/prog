import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class button3 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Frame with a counter ");
        frame.setBounds(500, 500 , 300, 400);
        frame.setLayout(new FlowLayout(FlowLayout.CENTER, 30,40));
        int n=10;
        Random rand= new Random();
        for (int i=0; i<n; i++){
            if (i<n/2){
                JButton button= new JButton();
                char letter =(char) (rand.nextInt(25)+'A');
                button.setText(String.valueOf(letter));
                button.addActionListener(e ->{
                    button.setBackground(Color.BLUE);
                    button.setBackground(Color.RED);
                });
                frame.add(button);
            }
            else {
                JButton button= new JButton();
                int number= rand.nextInt(25)+'A';
                button.setText(String.valueOf(number));
                button.addActionListener(e -> {
                    button.setBackground(Color.RED);
                    button.setBackground(Color.BLACK);
                    button.setSize(50, 50);
                });
                frame.add(button);

            }
        }
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(3);
    }
}

